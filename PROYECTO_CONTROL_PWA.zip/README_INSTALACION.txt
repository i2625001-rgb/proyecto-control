PROYECTO CONTROL — INSTALACIÓN

1. Esta carpeta contiene una PWA.
2. Para que Android permita instalarla como aplicación, debe estar publicada mediante HTTPS.
3. Una opción sencilla es GitHub Pages.
4. Sube TODOS estos archivos a un repositorio.
5. Activa GitHub Pages desde Settings > Pages.
6. Abre la dirección que GitHub te entregue en Chrome Android.
7. Pulsa "Instalar en mi celular" si aparece, o Chrome > ⋮ > "Añadir a pantalla de inicio".

IMPORTANTE:
- Los datos de tareas, hábitos, gastos e información de ahorro se guardan localmente en el dispositivo mediante localStorage.
- No introduzcas contraseñas ni información sensible.
